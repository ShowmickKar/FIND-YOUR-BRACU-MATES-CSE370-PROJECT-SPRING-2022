<?php

$mysqli = new mysqli('localhost', 'root', '', '370 project') or die(mysqli_error($mysqli));





// // Alumni Registration
// if (isset($_POST['register_alumni'])) {
//     $name = $_POST['name'];
//     $type = "alumni";
//     $company = $_POST['company'];
//     $graduation_date = $_POST['graduation_date'];
//     $department = $_POST['department'];
//     $email = $_POST['email'];
//     $linkedin = $_POST['linkedin'];
//     $password = $_POST['password'];
//     $areas_of_expertise = $_POST['expertise'];


//     // Prevent multiple registration
//     $sql = "SELECT * FROM alumni WHERE  email='$email'";
//     $result = $mysqli->query($sql);
//     $row = $result->fetch_assoc();
//     if ($result) {

//         if (mysqli_num_rows($result) >= 1) {
//         } else {
//             $mysqli->query("INSERT INTO alumni(name, company, graduation_date, department, email, linkedin, password) VALUES('$name','$company','$graduation_date', '$department', '$email', '$linkedin', '$password')") or die($mysqli->error);

//             // Store the area of expertise in alumni_area_of_expertise table
//             $sql = "SELECT id FROM `alumni` WHERE `email` LIKE '$email'";
//             $result = $mysqli->query($sql);
//             $row = mysqli_fetch_array($result);
//             $alumni_id = $row[0];

//             foreach ($areas_of_expertise as $expertise) {
//                 $mysqli->query("INSERT INTO `alumni_area_of_expertise` (`al_id`, `expertise`) VALUES ('$alumni_id','$expertise');");
//             }
//         }
//     }
// }

// // Alumni Login

// if (isset($_POST['login_alumni'])) {
//     $email = $_POST["email"];
//     $password = $_POST["password"];

//     $sql = "SELECT * FROM alumni WHERE  email='$email' AND password='$password'";
//     $result = $mysqli->query($sql);

//     $row = $result->fetch_assoc();
//     if ($result) {

//         if (mysqli_num_rows($result) >= 1) {
//             header("Location: alumni_profile.php");
//             exit();
//         } else {
//             echo "FAIL";
//         }
//     }
// }

// Donor Registration
if (isset($_POST['register_donor'])) {
    $name = $_POST['name'];
    $type = "donor";
    $phone = $_POST['phone'];
    $date_of_birth = $_POST['DOB'];
    $id = $_POST['d_id'];
    $email = $_POST['mail'];
    $blood_group = $_POST['blood_group'];
    $last_donation = $_POST['last_donation'];
    $weight = $_POST['weight'];
    
    $available_location = $_POST['expertise0'];
    
    $password = $_POST['password'];
    $areas_of_expertise = $_POST['expertise'];
    // $today=date("d-m-Y");
    // $diff=date_diff((date_create($date_of_birth)),date_create($today));
    // // $age = $_POST['$age->format("%y")'];


    // Prevent multiple registration
    $sql = "SELECT * FROM donor WHERE  email='$email'";
    $result = $mysqli->query($sql);
    $row = $result->fetch_assoc();
    if ($result) {

        if (mysqli_num_rows($result) >= 1) {
        } else {
            $mysqli->query("INSERT INTO donor(d_id, name, phone,mail,DOB, blood_group,last_donation,weight,age, password) VALUES('$id','$name','$phone','$email', '$date_of_birth', '$blood_group', '$last_donation','$weight','$age', '$password')") or die($mysqli->error);

            // Store the area of expertise in alumni_area_of_expertise table
            $sql = "SELECT d_id FROM `donor` WHERE `email` LIKE '$email'";
            $result = $mysqli->query($sql);
            $row = mysqli_fetch_array($result);
            $donor_id = $row[0];


            foreach ($areas_of_expertise as $expertise) {
                $mysqli->query("INSERT INTO `donor_health_condition` (`d_id`, `expertise`) VALUES ('$donor_id','$expertise');");
                
            }
            foreach ($available_location as $expertise0) {
                $mysqli->query("INSERT INTO `donor_available_locations` (`d_id`, `expertise0`) VALUES ('$donor_id','$expertise0');");
                
            }
        }
    }
}

// Donor Login
if (isset($_POST['login_donor'])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM donor WHERE  email='$email' AND password='$password'";
    $result = $mysqli->query($sql);

    $row = $result->fetch_assoc();
    if ($result) {

        if (mysqli_num_rows($result) >= 1) {
            header("Location: donor_profile.php");
            exit();
        } else {
            echo "FAIL";
        }
    }
}